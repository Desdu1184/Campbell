/*
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 * All rights reserved.
 *
 * This source code is licensed under the license found in the
 * LICENSE file in the root directory of this source tree.
 */

#define FBAEMKit_VERSION_STRING @"12.3.1"
#define FBSDK_DEFAULT_GRAPH_API_VERSION @"v12.0"
